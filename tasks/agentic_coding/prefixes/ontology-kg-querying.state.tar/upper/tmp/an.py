import sys, glob, re
from rdflib import Graph, Namespace, URIRef, Literal
ARC=Namespace("http://data.arcrail.eu/ontology#")
d=sys.argv[1]
g=Graph()
for f in sorted(glob.glob(d+"/*.ttl")):
    g.parse(f, format="turtle")
print("triples", len(g))
ops={}
for s,p,o in g.triples((None, ARC.opId, None)):
    ops.setdefault(str(o),[]).append(s)
for k in sorted(ops):
    recs=ops[k]
    print(k)
    for r in recs:
        cs=list(g.objects(r, ARC.inCountry))
        lc=list(g.objects(r, ARC.hasGeographicLocation))
        lat=lon=None
        if lc:
            lat=list(g.objects(lc[0], Namespace("http://www.w3.org/2003/01/geo/wgs84_pos#").lat))
            lon=list(g.objects(lc[0], Namespace("http://www.w3.org/2003/01/geo/wgs84_pos#long")))
            wkt=list(g.objects(lc[0], Namespace("http://www.opengis.net/ont/geosparql#asWKT")))
        else:
            wkt=[]
        ct=list(g.objects(r, ARC.wgs84CoordinateText))
        lt=list(g.objects(r, ARC.wgs84LatitudeText))
        gt=list(g.objects(r, ARC.wgs84LongitudeText))
        created=list(g.objects(r, URIRef("http://purl.org/dc/terms/created")))
        secs=[str(x).split('#')[-1] for x in list(g.subjects(ARC.startsAt, r))+list(g.subjects(ARC.endsAt, r))]
        print("   ", str(r).split('/')[-1], [str(c).split('#')[-1] for c in cs], "created", [str(c) for c in created],
              "lat",lat,"lon",lon,"wkt",wkt,"ct",ct,"latT",lt,"lonT",gt,"secs",secs)
